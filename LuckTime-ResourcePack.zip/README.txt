LuckTime Resource Pack
======================

ВАЖНО: Положи текстуру talisman_crusher.png в:
ResourcePack/assets/minecraft/textures/item/talisman_crusher.png

Затем создай архив:
Compress-Archive -Path "ResourcePack\*" -DestinationPath "LuckTime-ResourcePack.zip" -Force

Установка:
1. Залей LuckTime-ResourcePack.zip на хостинг (GitHub, Dropbox)
2. Получи прямую ссылку
3. В server.properties добавь:

resource-pack=https://твоя-ссылка/LuckTime-ResourcePack.zip
resource-pack-sha1=<новый SHA1 после добавления текстуры>
require-resource-pack=true

4. Перезапусти сервер

Получить новый SHA1:
certutil -hashfile "LuckTime-ResourcePack.zip" SHA1
